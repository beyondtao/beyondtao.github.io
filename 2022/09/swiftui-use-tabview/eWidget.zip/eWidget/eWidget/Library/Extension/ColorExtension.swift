//
//  ColorExtension.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import Foundation
import SwiftUI

extension Color {
    
    /// hex: 使用 16进制颜色
    /// - Parameters:
    ///   - hex: 十六进制整型数据 (eg: 0xF9E5C4)
    ///   - opacity: 透明度
    init(hex: UInt, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: opacity
        )
    }
    
    /// random: 生成随机颜色
    /// - Returns: 随机颜色
    static func random() -> Color {
        let red = Double(Int.random(in: 0...255)) / 255.0
        let green = Double(Int.random(in: 0...255)) / 255.0
        let blue = Double(Int.random(in: 0...255)) / 255.0
        return Color(red: red, green: green, blue: blue, opacity: 1)
    }
}
