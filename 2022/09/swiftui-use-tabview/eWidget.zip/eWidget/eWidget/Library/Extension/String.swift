//
//  String.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

extension String {
    func localized(withComment comment: String? = nil) -> String {
        return NSLocalizedString(self, comment: comment ?? "")
    }
    
    // "Welcome %@, this is my app"
    func LWithParam(parameters: [String]) -> String {
        return String(format: NSLocalizedString(self, comment: ""), arguments: parameters)
    }
    
    static func getCurrentLanguage() -> String {
        let preferredLang = Bundle.main.preferredLocalizations.first
        print("System Language:\(String(describing: preferredLang))")
        
        switch preferredLang {
        case "en-US", "en-CN":
            return "en"
        case "zh-Hans-US", "zh-Hans-CN", "zh-Hant-CN", "zh-TW", "zh-HK", "zh-Hans":
            return "cn"
        case "de":
            return "de"
        default:
            return ""
        }
    }
}
