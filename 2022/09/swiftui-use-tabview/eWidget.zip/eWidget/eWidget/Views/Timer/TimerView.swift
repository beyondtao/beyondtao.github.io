//
//  TimerView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct TimerView: View {
    var body: some View {
        Color(.cyan).ignoresSafeArea()
        Text("Timer")
    }
}

struct TimerView_Previews: PreviewProvider {
    static var previews: some View {
        TimerView()
    }
}
