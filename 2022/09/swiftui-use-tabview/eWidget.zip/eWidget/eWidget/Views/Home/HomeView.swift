//
//  HomeView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct HomeView: View {
    @State var isActive = false
    var body: some View {
//        Color(hex: 0x17203A).ignoresSafeArea()
        
        GeometryReader { proxy in
            ZStack {
                Color.green
                      .edgesIgnoringSafeArea(.all)
                VStack {
                    Text("Hello, World!")
                        .onTapGesture {
                            isActive.toggle()
                            print("=======")
                        }
                    NavigationLink(destination: ToolView(), isActive: $isActive) {
                        
                    }
                    .isDetailLink(false)    // hidden system back
                    Text("Hello, World!")
                    Image(systemName: "person")
        //                .foregroundColor(.black)
                }
                .padding()
                .background(Color(.orange))
        //        .padding(.bottom, 30)
            }
        }
//        .navigationBarHidden(true)
        
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
