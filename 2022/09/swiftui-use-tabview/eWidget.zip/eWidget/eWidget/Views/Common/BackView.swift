//
//  BackView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/19.
//

import SwiftUI

struct BackView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        ZStack {
            Color.cyan
                  .edgesIgnoringSafeArea(.all)
            
            VStack {
                Text("BackView")
            }
            .navigationBarItems(leading: Button(action: {
                print("back action...")
                self.presentationMode.wrappedValue.dismiss()
            }, label: {
                Text("Back Test")
                    .foregroundColor(.white)
            })
        )
        }
    }
}

struct BackView_Previews: PreviewProvider {
    static var previews: some View {
        BackView()
    }
}
