//
//  MenuRowView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/15.
//

import SwiftUI

struct MenuRowView: View {
    
    var item: MenuItem
    @Binding var selectedMenu: SelectedMenu
    
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: item.icon)
                .frame(width: 32, height: 32)
                .opacity(0.6)
            Text(item.text)
                .font(.headline)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(.blue)
                .frame(maxWidth: selectedMenu == item.menu ? .infinity : 0)
                .frame(maxWidth: .infinity, alignment: .leading)
        )
        .background(Color(hex: 0x17203A))
        .onTapGesture {
//            try? item.icon.setInput("active", value: true)
//            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//                try? item.icon.setInput("active", value: false)
//            }
            withAnimation(.timingCurve(0.2, 0.8, 0.2, 1)) {
                selectedMenu = item.menu
            }
        }
    }
}

struct MenuRowView_Previews: PreviewProvider {
    static var previews: some View {
        MenuRowView(item: menuItems[0], selectedMenu: .constant(.home))
    }
}
