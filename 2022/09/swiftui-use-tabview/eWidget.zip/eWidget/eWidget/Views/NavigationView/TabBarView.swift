//
//  TabBarView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct TabBarView: View {
    
    @Binding var selectedTab: TabEnum
    var safeEdgeInsets: EdgeInsets
    
    var body: some View {
        VStack {
            Spacer()
            HStack {
                content
            }
            .padding(12)
            
//            .padding(.bottom, -10)
//            .background(Color(hex: 0x17203A))
            .background(Color(.black).opacity(0.8))
            .background(.ultraThinMaterial)
            .mask(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .shadow(color: .red.opacity(0.8), radius: 20, x: 0, y: 20)
            .overlay(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(.linearGradient(colors: [.white.opacity(0.5), .white.opacity(0)], startPoint: .topLeading, endPoint: .bottomTrailing))
            )
            .padding(.horizontal, 24)
        }
        .padding(.bottom, safeEdgeInsets.bottom == 0 ? 20 : safeEdgeInsets.bottom + 10)
    }
    
    var content: some View {
        
        ForEach(tabItems) { item in
            Button {
                withAnimation {
                    selectedTab = item.tab
                }
            } label: {
                Image(systemName: item.icon)
                    .frame(height: 36)
                    .foregroundColor(.white)
                    .opacity(selectedTab == item.tab ? 1 : 0.5)
                    .background(
                        VStack {
                            RoundedRectangle(cornerRadius: 2)
                                .fill(Color.accentColor)
                                .frame(width: selectedTab == item.tab ? 30 : 0, height: 4)
                                .offset(y: -4)
                                .opacity(selectedTab == item.tab ? 1 : 0)
                            Spacer()
                        }
                    )
            }
            // 让 tabBarItem 宽度等分
            .frame(maxWidth: .infinity)
        }
    }
}

struct TabBarView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarView(selectedTab: .constant(.home), safeEdgeInsets: EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
    }
}

struct TabItem: Identifiable {
    var id = UUID()
    var icon: String
    var tab: TabEnum
}

var tabItems = [
    TabItem(icon: "house", tab: .home),
    TabItem(icon: "bag.badge.plus", tab: .tool),
    TabItem(icon: "alarm.waves.left.and.right", tab: .timer),
    TabItem(icon: "person", tab: .my),
]

enum TabEnum: String {
    case home
    case tool
    case timer
    case my
}

