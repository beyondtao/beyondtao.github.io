//
//  TabBarTest.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/19.
//

import SwiftUI

struct TabBarTest: View {
    @State private var selectedTab = 0
    var body: some View {
        NavigationView {
            TabView(selection: $selectedTab){
                HomeView().tabItem {
                    Image(systemName: "arkit").foregroundColor(.red)
                    Text("设置一")
                }.onTapGesture {
                    self.selectedTab = 3
                }.tag(0)
                
                ToolView().tabItem {
                    Image(systemName: "star")
                    Text("设置二")
                }.tag(1)
                
                TimerView().tabItem {
                    Image(systemName: "star").foregroundColor(.red)
                    Text("设置三")
                }.tag(2)
                
                MyView().tabItem {
                    Image(systemName: "star").foregroundColor(.red)
                    Text("设置四")
                }.tag(3)
            }
        }
    }
}

struct TabBarTest_Previews: PreviewProvider {
    static var previews: some View {
        TabBarTest()
    }
}
