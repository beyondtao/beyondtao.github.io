//
//  SplashScreenView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct SplashScreenView<Content: View, Title: View, Logo: View, NavButton: View>: View {
    
    var contentView: Content
    var titleView: Title
    var logoView: Logo
    var navButton: NavButton
    
    var imageSize: CGSize
    
    init(imageSize: CGSize,
         @ViewBuilder contentView: @escaping () -> Content,
         @ViewBuilder titleView: @escaping () -> Title,
         @ViewBuilder logoView: @escaping () -> Logo,
         @ViewBuilder navButton: @escaping () -> NavButton) {
        self.contentView = contentView()
        self.titleView = titleView()
        self.logoView = logoView()
        self.navButton = navButton()
        
        self.imageSize = imageSize
    }
    
    // Animation Properties...
    @State var textAnimation: Bool = false
    @State var imageAnimation = false
    @State var endAnimation = false
    @State var showNavButtons = false
    
    // NameSpace...
    @Namespace var animation
    
    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                Color.clear
                    // were not going to do complex reading of top edge...
                    // simply apply overlay or background it will automatically fill edges...
                    .background(Color.purple)
                    // But the frame will be safe area...
                    .overlay {
                        ZStack {
                            // textAnimation space ? (before ? must has a space, if not, so funny)
                            titleView
                                .scaleEffect(endAnimation ? 0.75 : 1)
                                .offset(y: textAnimation ? -5 : 110)
                            if !endAnimation {
                                logoView
                                    .matchedGeometryEffect(id: "logo", in: animation)
                                    .frame(width: imageSize.width, height: imageSize.height)
                            }
                        }
                    }
                    .overlay {
                        // Moving Right
                        HStack {
                            // Later Used for nav Buttons...
                            navButton
                                .opacity(showNavButtons ? 1 : 0)

                            Spacer()

                            if endAnimation {
                                logoView
                                    .matchedGeometryEffect(id: "logo", in: animation)
                                    .frame(width: 30, height: 30)
                            }
                        }
                        .padding(.horizontal)
                        .offset(y: -5)
                    }
            }
            .frame(height: endAnimation ? 44 : nil)
            .opacity(endAnimation ? 0 : 1)
            .zIndex(1)
            
            // Home View
            contentView
                .frame(height: endAnimation ? nil : 0)
                // moving back view...
                .zIndex(0)
        }
        .frame(maxHeight: .infinity, alignment: .top)
        .onAppear() {
            // Starting Animation with some delay...
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                withAnimation(.spring()) {
                    textAnimation.toggle()
                }
                
                // Directly Ending Animation...
                withAnimation(Animation.interactiveSpring(response: 0.6, dampingFraction: 1, blendDuration: 1)) {
                    endAnimation.toggle()
                }
                
                // Showing after some Delay
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    withAnimation {
                        showNavButtons.toggle()
                    }
                }
            }
        }
    }
}

struct BootAnimationView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView(imageSize: CGSize(width: 128, height: 128)) {
            
        } titleView: {
            Text("Chatty")
                .font(.system(size: 35).bold())
                .foregroundColor(.white)
        } logoView: {
            Image("Logo Apple")
                .resizable()
        } navButton: {
            // Your Nav Bar Buttons..
            Button {
                
            } label: {
                Image("Logo Apple")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 40, height: 40)
                    .clipShape(Circle())
            }
        }
    }
}
