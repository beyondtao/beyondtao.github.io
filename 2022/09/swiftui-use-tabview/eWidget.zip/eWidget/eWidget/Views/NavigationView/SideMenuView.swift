//
//  SideMenuView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct SideMenuView: View {
    
    @State var selectedMenu: SelectedMenu = .home
    @State var isDarkMode = false
    
    var body: some View {
        VStack {
            HStack {
                Image(systemName: "person")
                    .padding(12)
                    .background(.white.opacity(0.2))
                    .mask(Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text("Scott Tao")
                        .font(.body)
                    Text("iOS Developer")
                        .font(.subheadline)
                }
                Spacer()
            }
            .padding(12)
            
            Text("BROWSE")
                .font(.subheadline)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 24)
                .padding(.top, 20)
                .opacity(0.7)
            VStack(alignment: .leading, spacing: 0) {
                ForEach(menuItems) { item in
                    Rectangle()
                        .frame(height: 1)
                        .opacity(0.1)
                        .padding()
                    MenuRowView(item: item, selectedMenu: $selectedMenu)
                }
            }
            .padding(8)
            
            Text("HISTORY")
                .font(.subheadline)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 24)
                .padding(.top, 40)
                .opacity(0.7)
            
            VStack(alignment: .leading, spacing: 0) {
                ForEach(menuItems2) { item in
                    Rectangle()
                        .frame(height: 1)
                        .opacity(0.1)
                        .padding(.horizontal)
                    MenuRowView(item: item, selectedMenu: $selectedMenu)
                }
            }
            
            Spacer()
            
            HStack {
                Image(systemName: menuItems3[0].icon)
                    .frame(width: 32, height: 32)
                    .opacity(0.6)
                    .onChange(of: isDarkMode) { newValue in
//                        if newValue {
//                            try? menuItems3[0].icon.setInput("active", value: true)
//                        } else {
//                            try? menuItems3[0].icon.setInput("active", value: false)
//                        }
                    }
                Text(menuItems3[0].text)
                    .font(.headline)
                Toggle("", isOn: $isDarkMode)
            }
            .padding(20)
        }
        .foregroundColor(.white)
        .frame(maxWidth: 288, maxHeight: .infinity)
        .background(Color(hex: 0x17203A))
        .mask(RoundedRectangle(cornerRadius: 30, style: .continuous))
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct SideMenuView_Previews: PreviewProvider {
    static var previews: some View {
        SideMenuView()
    }
}



struct MenuItem: Identifiable {
    var id = UUID()
    var text: String
    var icon: String
    var menu: SelectedMenu
}

var menuItems = [
    MenuItem(text: "Home", icon: "house", menu: .home),
    MenuItem(text: "Search", icon: "house", menu: .search),
    MenuItem(text: "Favorites", icon: "house", menu: .favorites),
    MenuItem(text: "Help", icon: "house", menu: .help),
]

var menuItems2 = [
    MenuItem(text: "History", icon: "house", menu: .history),
    MenuItem(text: "Notifications", icon: "house", menu: .notifications),
]

var menuItems3 = [
    MenuItem(text: "Dark Mode", icon: "house", menu: .darkmode),
]

enum SelectedMenu: String {
    case home
    case search
    case favorites
    case help
    case history
    case notifications
    case darkmode
}
