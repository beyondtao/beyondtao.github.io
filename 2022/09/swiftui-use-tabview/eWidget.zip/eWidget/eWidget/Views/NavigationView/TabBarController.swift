//
//  TabBarController.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct TabBarController: View {
    @State var currTab: TabEnum = .home
    
//    @StateObject var tabBarVM: TabBarViewModel = TabBarViewModel()
    
    var body: some View {
        GeometryReader { proxy in
            Group {
                switch currTab {
                case .home:
                    HomeView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
//                        .environmentObject(<#T##object: ObservableObject##ObservableObject#>)
                case .tool:
                    ToolView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                case .timer:
                    TimerView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                case .my:
                    MyView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
//            .safeAreaInset(edge: .bottom) {
//                Color.cyan.frame(height: 80)
//            }
//            .safeAreaInset(edge: .top) {
//                Color.cyan.frame(height: 104)
//            }
            .ignoresSafeArea()
//            ZStack(alignment: .bottom) {
//                TabView(selection: $currTab) {
//                    HomeView()
//                        .frame(maxWidth: .infinity, maxHeight: .infinity)
//                        .tag(TabEnum.home)
//                    ToolView()
//                        .frame(maxWidth: .infinity, maxHeight: .infinity)
//                        .tag(TabEnum.tool)
//                    TimerView()
//                        .frame(maxWidth: .infinity, maxHeight: .infinity)
//                        .tag(TabEnum.timer)
//                    MyView()
//                        .frame(maxWidth: .infinity, maxHeight: .infinity)
//                        .tag(TabEnum.my)
//                }
//            }
            
//            .safeAreaInset(edge: .bottom) {
//                Color.green.frame(height: 80)
//            }
//            .safeAreaInset(edge: .top) {
//                Color.green.frame(height: 104)
//            }
//            .ignoresSafeArea()
            TabBarView(selectedTab: $currTab, safeEdgeInsets: proxy.safeAreaInsets)
//                .offset(y: 40)
        }
        .ignoresSafeArea(.all, edges: .bottom)
    }
}

struct TabBarController_Previews: PreviewProvider {
    static var previews: some View {
        TabBarController()
    }
}
