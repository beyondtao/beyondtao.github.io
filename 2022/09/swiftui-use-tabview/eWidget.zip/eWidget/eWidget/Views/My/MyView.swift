//
//  MyView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct MyView: View {
    var body: some View {
        Color(.white).ignoresSafeArea()
        Text("My!")
    }
}

struct MyView_Previews: PreviewProvider {
    static var previews: some View {
        MyView()
    }
}
