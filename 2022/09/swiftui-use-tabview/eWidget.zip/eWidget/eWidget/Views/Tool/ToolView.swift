//
//  ToolView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct ToolView: View {
    
    
    
    var body: some View {
        ZStack {
            Color.red
                  .edgesIgnoringSafeArea(.all)
            Text("morning")
        }
    }
}

struct ToolView_Previews: PreviewProvider {
    static var previews: some View {
        ToolView()
    }
}
