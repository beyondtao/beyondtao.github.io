//
//  ContentView.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
//        RootView()
        NavigationView {
            TabBarController()
        }
//        SplashScreenView(imageSize: CGSize(width: 128, height: 128)) {
//            RootView()
//        } titleView: {
//            Text("Chatty")
//                .font(.system(size: 35).bold())
//                .foregroundColor(.white)
//        } logoView: {
//            Image("Logo Apple")
//                .resizable()
//        } navButton: {
//            // Your Nav Bar Buttons..
//            Button {
//
//            } label: {
//                Image("Logo Apple")
//                    .resizable()
//                    .aspectRatio(contentMode: .fill)
//                    .frame(width: 40, height: 40)
//                    .clipShape(Circle())
//            }
//        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
