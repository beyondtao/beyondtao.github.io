//
//  eWidgetApp.swift
//  eWidget
//
//  Created by 陶先生 on 2022/9/16.
//

import SwiftUI

@main
struct eWidgetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
