//
//  CardView.swift
//  WidgetApp
//
//  Created by Scott on 2022/10/10.
//

import SwiftUI

struct CardView: View {
    let title: String
    let color: Color = .random
    var body: some View {
        VStack {
            RoundedRectangle(cornerRadius: 12).foregroundColor(color)
            Text(title)
                .font(.title2)
        }
        
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView(title: "Hello world")
    }
}

extension Color {
    static var random: Color {
        return Color(
            red: .random(in: 0...1),
            green: .random(in: 0...1),
            blue: .random(in: 0...1)
        )
    }
}

struct MockStore {
    static var cards = [
        Card(title: "Sun"),
        Card(title: "Mercury"),
        Card(title: "Venus"),
        Card(title: "Earth"),
        Card(title: "Mars"),
        Card(title: "Jupiter"),
        Card(title: "Saturn"),
        Card(title: "Uranus"),
        Card(title: "Neptune"),
        Card(title: "Pluto"),
        Card(title: "Solar System"),
        Card(title: "Galaxy"),
        Card(title: "Universe"),
        Card(title: "Remote Antiquity"),
        Card(title: "Foreworld"),
    ]
}

struct Card: Identifiable, Hashable {
    let id = UUID()
    let title: String
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
//        hasher.combine(title)
    }
}
