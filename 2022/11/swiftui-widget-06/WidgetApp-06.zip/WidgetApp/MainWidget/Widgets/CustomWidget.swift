//
//  CustomWidget.swift
//  WidgetApp
//
//  Created by Scott on 2022/10/7.
//

import SwiftUI
import WidgetKit

struct CustomProvider: IntentTimelineProvider {
    func placeholder(in context: Context) -> CustomEntry {
        CustomEntry(date: Date(), configuration: CustomConfigurationIntent())
    }

    func getSnapshot(for configuration: CustomConfigurationIntent, in context: Context, completion: @escaping (CustomEntry) -> ()) {
        let entry = CustomEntry(date: Date(), configuration: configuration)
        completion(entry)
    }

    func getTimeline(for configuration: CustomConfigurationIntent, in context: Context, completion: @escaping (Timeline<CustomEntry>) -> ()) {
        var entries: [CustomEntry] = []

        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .hour, value: hourOffset, to: currentDate)!
            let entry = CustomEntry(date: entryDate, configuration: configuration)
            entries.append(entry)
        }

        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }
}

struct CustomEntry: TimelineEntry {
    let date: Date
    let configuration: CustomConfigurationIntent
}

// Widget View
struct CustomWidgetEntryView : View {
    var entry: CustomProvider.Entry

    var body: some View {
        if entry.configuration.SecondType?.displayString == "" {
            Text(entry.date, style: .time)
        } else {
            ZStack {
                Image("wazi")
                    .resizable()
                    .scaledToFill()
                Text(entry.configuration.SecondType?.displayString ?? "")
                    .font(.title2)
                    .foregroundColor(.white)
            }
        }
    }
}

struct CustomWidget: Widget {
    let kind: String = "MainWidget"

    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: CustomConfigurationIntent.self, provider: CustomProvider()) { entry in
            CustomWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
        .supportedFamilies([.systemMedium])
    }
}


struct CustomWidget_Previews: PreviewProvider {
    static var previews: some View {
        CustomWidgetEntryView(entry: CustomEntry(date: Date(), configuration: CustomConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemSmall))
    }
}
