//
//  WidgetAppApp.swift
//  WidgetApp
//
//  Created by Scott on 2022/10/7.
//

import SwiftUI

@main
struct WidgetAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
