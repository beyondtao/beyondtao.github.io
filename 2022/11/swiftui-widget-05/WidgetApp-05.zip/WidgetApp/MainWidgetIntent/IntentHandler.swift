//
//  IntentHandler.swift
//  MainWidgetIntent
//
//  Created by Scott on 2022/11/8.
//

import Intents

class IntentHandler: INExtension, ConfigurationIntentHandling {
    
    override func handler(for intent: INIntent) -> Any {
        // This is the default implementation.  If you want different objects to handle different intents,
        // you can override this and return the handler you want for that particular intent.
        
        return self
    }
    
    // provide [Parameter] OptionsCollection    // in the Intentdefinition
    func provideExchangeOptionsCollection(for intent: ConfigurationIntent, with completion: @escaping (INObjectCollection<CustomExchange>?, Error?) -> Void) {
        // Create a collection with the array of characters.
        let collection = INObjectCollection(items: IntentHandler.exchanges)
        // Call the completion handler, passing the collection.
        completion(collection, nil)
    }
    
    public static var exchanges: [CustomExchange] {
        [
            CustomExchange(identifier: "CNY", display: "人民币"),
            CustomExchange(identifier: "USD", display: "美元"),
            CustomExchange(identifier: "GBP", display: "英镑"),
            CustomExchange(identifier: "EUR", display: "欧元"),
            CustomExchange(identifier: "CAD", display: "加拿大元"),
            CustomExchange(identifier: "HKD", display: "港元"),
            CustomExchange(identifier: "MOP", display: "澳门元"),
            CustomExchange(identifier: "THB", display: "泰铢"),
            CustomExchange(identifier: "SGD", display: "新加坡元"),
        ]
    }
}
