//
//  ContentView.swift
//  WidgetApp
//
//  Created by Scott on 2022/10/7.
//

import SwiftUI

struct ContentView: View {
    var columns: [GridItem] = [
        GridItem(.flexible(minimum: 140)),
        GridItem(.flexible()),
        GridItem(.flexible()),
    ]
    
    let cards: [Card] = MockStore.cards
    
    var body: some View {
        NavigationStack {
            ScrollView(.vertical, showsIndicators: false) {
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(cards) { card in
                    
                        NavigationLink(value: card) {
                            CardView(title: card.title)
                                .frame(height: 150)
                        }
                        .navigationDestination(for: Card.self) { card in
                            Text(card.title)
                                .foregroundColor(.orange)
                                .font(.system(size: 100))
                        }
                        
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
