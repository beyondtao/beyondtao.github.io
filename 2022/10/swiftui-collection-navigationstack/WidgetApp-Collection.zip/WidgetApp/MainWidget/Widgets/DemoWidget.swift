//
//  DemoWidget.swift
//  WidgetApp
//
//  Created by Scott on 2022/10/7.
//

import SwiftUI

import WidgetKit

struct DemoProvider: IntentTimelineProvider {
    func placeholder(in context: Context) -> DemoEntry {
        DemoEntry(date: Date(), configuration: ConfigurationIntent())
    }

    func getSnapshot(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (DemoEntry) -> ()) {
        let entry = DemoEntry(date: Date(), configuration: configuration)
        completion(entry)
    }

    func getTimeline(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (Timeline<DemoEntry>) -> ()) {
        
        // First refresh time: 2 seconds delay
        let firstDate = DemoProvider.getFirstEntryDate()
        // Second refresh time: When at the first full minute refresh
        let firstMinuteDate = DemoProvider.getFirstMinuteEntryDate()
        
        var entries: [DemoEntry] = []
        entries.append(DemoEntry(date: firstDate, configuration: configuration))
        entries.append(DemoEntry(date: firstMinuteDate, configuration: configuration))
        
        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        for offset in 1 ..< 5 {
            guard let entryDate = Calendar.current.date(byAdding: .minute, value: offset, to: firstMinuteDate) else {
                continue
            }
            let entry = DemoEntry(date: entryDate, configuration: configuration)
            entries.append(entry)
        }

        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }
    
    static func getFirstEntryDate() -> Date {
        let offsetSecond: TimeInterval = TimeInterval(2)
        var currentDate = Date()
        currentDate += offsetSecond
        return currentDate
    }
    
    // Get the time point of the first minute time point
    // eg: 14:10:00
    static func getFirstMinuteEntryDate() -> Date {
        var currentDate = Date()
        let passSecond = Calendar.current.component(.second, from: currentDate)
        let offsetSecond: TimeInterval = TimeInterval(60 - passSecond)
        currentDate += offsetSecond
        return currentDate
    }
}

struct CYClockTime {
    var sec: Int
    var min: Int
    var hour: Int
}

struct DemoEntry: TimelineEntry {
    let date: Date
    let configuration: ConfigurationIntent
    
    func clockTime() -> CYClockTime {
        let date = self.date
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: date)
        let min = calendar.component(.minute, from: date)
        let sec = calendar.component(.second, from: date)
        print("\(hour) \(min) \(sec) || \(self.date)")
        return CYClockTime(sec: sec, min: min, hour: hour)
    }
    
    func clockHHss() -> String {
        let hour = String(format: "%.2d", clockTime().hour)
        let min = String(format: "%.2d", clockTime().min)
        return hour + " " + min
    }
}

// Widget View
struct DemoWidgetEntryView : View {
    var entry: DemoProvider.Entry

    let width = (UIScreen.main.bounds.width - 50) / 3
    
    var body: some View {
        
        switch entry.configuration.type {
        case .image:
            Image("wazi")
                .resizable()
                .scaledToFill()
        case .time:
            Text("\(entry.clockHHss())")
        case .clock:
            ZStack {
                Color(.cyan).ignoresSafeArea()
                HStack {
                    Image("taiji")
                        .resizable()
                        .scaledToFill()
                        .scaledToFit()
                    .frame(width: width)
                    
                    Text("\(entry.clockHHss())")
                        .font(.system(size: 66))
                }
            }
        case .unknown:
            clockView
        }
    }
    
    var clockView: some View {
        ZStack {
            Color(.cyan).ignoresSafeArea()
            HStack {
                Image("taiji")
                    .resizable()
                    .scaledToFill()
                    .scaledToFit()
                .frame(width: width)
                
                Text("\(entry.clockHHss())")
                    .font(.system(size: 66))
            }
        }
    }
}

struct DemoWidget: Widget {
    let kind: String = "DemoWidget"

    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: ConfigurationIntent.self, provider: DemoProvider()) { entry in
            DemoWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("Demo Widget")
        .description("This is an Demo widget.")
    }
}


struct DemoWidget_Previews: PreviewProvider {
    static var previews: some View {
        DemoWidgetEntryView(entry: DemoEntry(date: Date(), configuration: ConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemMedium))
    }
}
