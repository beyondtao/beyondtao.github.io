//
//  MainWidget.swift
//  MainWidget
//
//  Created by Scott on 2022/10/7.
//

import WidgetKit
import SwiftUI
import Intents

@main // Use the customized WidgetBundle as the initialization entry of the widget
struct WidgetLauncher {
    
    static func main() {
        var isShowAll: Bool {
            // Put logic here
            true
        }
        
        if isShowAll {
            // load All Widgets
            CustomWidgetBundle.main()
        } else {
            // load selected Widgets
            CustomWidgetBundle1.main()
        }
    }
}

struct CustomWidgetBundle: WidgetBundle {
    @WidgetBundleBuilder
    var body: some Widget {
        CustomWidget()
        DemoWidget()
    }
}

struct CustomWidgetBundle1: WidgetBundle {
    @WidgetBundleBuilder
    var body: some Widget {
        CustomWidget()
    }
}

struct MainWidget_Previews: PreviewProvider {
    static var previews: some View {
        CustomWidgetEntryView(entry: SimpleEntry(date: Date(), configuration: ConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemSmall))
    }
}
