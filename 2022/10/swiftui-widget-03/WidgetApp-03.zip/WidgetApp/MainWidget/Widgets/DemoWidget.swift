//
//  DemoWidget.swift
//  WidgetApp
//
//  Created by Scott on 2022/10/7.
//

import SwiftUI

import WidgetKit

struct DemoProvider: IntentTimelineProvider {
    func placeholder(in context: Context) -> DemoEntry {
        DemoEntry(date: Date(), configuration: ConfigurationIntent())
    }

    func getSnapshot(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (DemoEntry) -> ()) {
        let entry = DemoEntry(date: Date(), configuration: configuration)
        completion(entry)
    }

    func getTimeline(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (Timeline<DemoEntry>) -> ()) {
        var entries: [DemoEntry] = []

        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .hour, value: hourOffset, to: currentDate)!
            let entry = DemoEntry(date: entryDate, configuration: configuration)
            entries.append(entry)
        }

        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }
}

struct DemoEntry: TimelineEntry {
    let date: Date
    let configuration: ConfigurationIntent
}

// Widget View
struct DemoWidgetEntryView : View {
    var entry: DemoProvider.Entry

    var body: some View {
        
        switch entry.configuration.type {
        case .image:
            Image("wazi")
                .resizable()
                .scaledToFill()
        case .time:
            Text(entry.date, style: .time)
        case .text:
            Text("Text")
        case .unknown:
            Text("Default")
        }
    }
}

struct DemoWidget: Widget {
    let kind: String = "MainWidget"

    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: ConfigurationIntent.self, provider: Provider()) { entry in
            CustomWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
    }
}


struct DemoWidget_Previews: PreviewProvider {
    static var previews: some View {
        DemoWidgetEntryView(entry: DemoEntry(date: Date(), configuration: ConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemSmall))
    }
}
