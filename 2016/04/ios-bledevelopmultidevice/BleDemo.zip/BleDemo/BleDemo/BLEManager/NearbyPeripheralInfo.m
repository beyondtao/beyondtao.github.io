//
//  NearbyPeripheralInfo.m
//  HealthGuard
//
//  Created by LaoTao on 15/11/26.
//  Copyright © 2015年 LaoTao. All rights reserved.
//

#import "NearbyPeripheralInfo.h"

@implementation NearbyPeripheralInfo



@end
