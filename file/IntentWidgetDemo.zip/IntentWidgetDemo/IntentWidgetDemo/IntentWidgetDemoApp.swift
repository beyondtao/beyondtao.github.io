//
//  IntentWidgetDemoApp.swift
//  IntentWidgetDemo
//
//  Created by Scott on 2022/9/24.
//

import SwiftUI

@main
struct IntentWidgetDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
