//
//  PhotoWidget.swift
//  IntentWidgetPhoto
//
//  Created by Scott on 2022/9/24.
//

import WidgetKit
import SwiftUI

struct PhotoProvider: IntentTimelineProvider {
    func placeholder(in context: Context) -> PhotoEntry {
        PhotoEntry(date: Date(), configuration: TimeTypeConfigurationIntent())
    }

    func getSnapshot(for configuration: TimeTypeConfigurationIntent, in context: Context, completion: @escaping (PhotoEntry) -> ()) {
        let entry = PhotoEntry(date: Date(), configuration: configuration)
        completion(entry)
    }

    func getTimeline(for configuration: TimeTypeConfigurationIntent, in context: Context, completion: @escaping (Timeline<PhotoEntry>) -> ()) {
        var entries: [PhotoEntry] = []

        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .hour, value: hourOffset, to: currentDate)!
            let entry = PhotoEntry(date: entryDate, configuration: configuration)
            entries.append(entry)
        }

        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }
}

struct PhotoEntry: TimelineEntry {
    let date: Date
    let configuration: TimeTypeConfigurationIntent
}

struct PhotoEntryView : View {
    var entry: PhotoProvider.Entry

    var body: some View {
        HStack {
//            Image("600")
//                .resizable()
//                .scaledToFill()
//                .scaledToFit()
//            Image("jun")
//                .resizable()
//                .scaledToFill()
            Image("wazi")
                .resizable()
                .scaledToFill()
        }
    }
}

struct PhotoWidget: Widget {
    let kind: String = "MainWidget"

    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: TimeTypeConfigurationIntent.self, provider: PhotoProvider()) { entry in
            PhotoEntryView(entry: entry)
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
    }
}

struct PhotoWidget_Previews: PreviewProvider {
    static var previews: some View {
        PhotoEntryView(entry: PhotoEntry(date: Date(), configuration: TimeTypeConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemMedium))
    }
}
