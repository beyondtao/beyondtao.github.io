//
//  DemoWidget.swift
//  IntentWidgetDemo
//
//  Created by Scott on 2022/9/24.
//

import WidgetKit
import SwiftUI

// IntentConfiguration 主要针对具有用户可配置属性的Widget
// StaticConfiguration 可以在不需要任何输入的情况下自行解析，可以在 Widget 的 App中获取相关数据并发送给Widget
struct DemoProvider: IntentTimelineProvider {
    func placeholder(in context: Context) -> DemoEntry {
//        DemoEntry(date: Date(), configuration: ConfigurationIntent())
        DemoEntry(date: Date(), configuration: TimeTypeConfigurationIntent())
    }

    func getSnapshot(for configuration: TimeTypeConfigurationIntent, in context: Context, completion: @escaping (DemoEntry) -> ()) {
        let entry = DemoEntry(date: Date(), configuration: configuration)
        completion(entry)
    }

    func getTimeline(for configuration: TimeTypeConfigurationIntent, in context: Context, completion: @escaping (Timeline<DemoEntry>) -> ()) {
        var entries: [DemoEntry] = []

        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .hour, value: hourOffset, to: currentDate)!
            let entry = DemoEntry(date: entryDate, configuration: configuration)
            entries.append(entry)
        }

        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }
}

struct DemoEntry: TimelineEntry {
    let date: Date
    // 多了一个配置参数，小组件编辑界面设置参数会通过这个传递进来
    let configuration: TimeTypeConfigurationIntent
}

struct DemoEntryView : View {
    var entry: DemoProvider.Entry

    var body: some View {
        VStack {
            switch entry.configuration.type {
            case .type1:
                Text("Time")
                Text(entry.date, style: .time)
            case .type2:
                let photoEntry = PhotoEntry(date: entry.date, configuration: entry.configuration)
                PhotoEntryView(entry: photoEntry)
            case .type3:
                Text("Text")
            case .unknown:
                Text(entry.date, style: .time)
            }
//                Text(entry.date, style: .time)
        }
        
    }
}


struct DemoWidget: Widget {
    let kind: String = "MainWidget"

    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: TimeTypeConfigurationIntent.self, provider: DemoProvider()) { entry in
            DemoEntryView(entry: entry)
        }
        .configurationDisplayName("可配置小组件")
        .description("选择不同的时间类型")
    }
}

struct DemoWidget_Previews: PreviewProvider {
    static var previews: some View {
        DemoEntryView(entry: DemoEntry(date: Date(), configuration: TimeTypeConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemSmall))
    }
}
