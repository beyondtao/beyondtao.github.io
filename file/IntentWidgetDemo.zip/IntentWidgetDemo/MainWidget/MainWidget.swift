//
//  MainWidget.swift
//  MainWidget
//
//  Created by Scott on 2022/9/24.
//

import WidgetKit
import SwiftUI
import Intents

@main // Use the customized WidgetBundle as the initialization entry of the widget
struct WidgetLauncher {
    
    static func main() {
        var isShowAll: Bool {
            // Put logic here
            true
        }
        
        if isShowAll {
            CustomWidgetBundle.main()
        } else {
            CustomWidgetBundle1.main()
        }
    }
}

struct CustomWidgetBundle: WidgetBundle {
    @WidgetBundleBuilder
    var body: some Widget {
        DemoWidget()
        PhotoWidget()
    }
}

struct CustomWidgetBundle1: WidgetBundle {
    @WidgetBundleBuilder
    var body: some Widget {
        PhotoWidget()
    }
}

struct MainWidget_Previews: PreviewProvider {
    static var previews: some View {
        DemoEntryView(entry: DemoEntry(date: Date(), configuration: TimeTypeConfigurationIntent()))
            .previewContext(WidgetPreviewContext(family: .systemMedium))
    }
}
