//
//  DaoAppApp.swift
//  DaoApp
//
//  Created by Scott on 2022/10/30.
//

import SwiftUI

@main
struct DaoAppApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
