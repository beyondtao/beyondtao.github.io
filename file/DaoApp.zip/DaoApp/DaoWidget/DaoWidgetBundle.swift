//
//  DaoWidgetBundle.swift
//  DaoWidget
//
//  Created by Scott on 2022/10/30.
//

import WidgetKit
import SwiftUI

@main
struct DaoWidgetBundle: WidgetBundle {
    var body: some Widget {
        DaoWidget()
        DaoWidgetLiveActivity()
    }
}
