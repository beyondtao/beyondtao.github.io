//
//  IntentHandler.swift
//  DaoAppIntents
//
//  Created by Scott on 2022/10/30.
//

import Intents

class IntentHandler: INExtension, ConfigurationIntentHandling {
    
    override func handler(for intent: INIntent) -> Any {
        // This is the default implementation.  If you want different objects to handle different intents,
        // you can override this and return the handler you want for that particular intent.
        
        return self
    }
    
    func provideExchangeOptionsCollection(for intent: ConfigurationIntent, with completion: @escaping (INObjectCollection<CustomeExchange>?, Error?) -> Void) {
//        let exchange: [CustomeExchange] = [
//            CustomeExchange(identifier: "CNY", display: "RMB"),
//            CustomeExchange(identifier: "USD", display: "Dollor"),
//            CustomeExchange(identifier: "GBP", display: "Pound"),
//            CustomeExchange(identifier: "EUR", display: "Euro"),
//            CustomeExchange(identifier: "CAD", display: "CAD"),
////            CustomeExchange(identifier: "HKD", display: "HKD"),
//        ]
        // Create a collection with the array of characters.
        let collection = INObjectCollection(items: IntentHandler.exchanges)
//        let collection = INObjectCollection(items: exchange)
        // Call the completion handler, passing the collection.
        completion(collection, nil)
    }
    
    func provideCustomExchangeOptionsCollection(for intent: ConfigurationIntent, with completion: @escaping (INObjectCollection<CustomeExchange>?, Error?) -> Void) {
        let exchange: [CustomeExchange] = [
            CustomeExchange(identifier: "CNY", display: "RMB"),
            CustomeExchange(identifier: "USD", display: "Dollor"),
            CustomeExchange(identifier: "GBP", display: "Pound"),
            CustomeExchange(identifier: "EUR", display: "Euro"),
            CustomeExchange(identifier: "CAD", display: "CAD"),
//            CustomeExchange(identifier: "HKD", display: "HKD"),
        ]
        // Create a collection with the array of characters.
//        let collection = INObjectCollection(items: IntentHandler.exchanges)
        let collection = INObjectCollection(items: exchange)
        // Call the completion handler, passing the collection.
        completion(collection, nil)
    }
//    func provideExchangeOptionsCollection(for intent: ConfigurationIntent) async throws -> INObjectCollection<Exchange> {
//
//    }
    
    public static var exchanges: [CustomeExchange] {
        [
            CustomeExchange(identifier: "CNY", display: "人民币"),
            CustomeExchange(identifier: "USD", display: "美元"),
            CustomeExchange(identifier: "GBP", display: "英镑"),
            CustomeExchange(identifier: "EUR", display: "欧元"),
            CustomeExchange(identifier: "CAD", display: "加拿大元"),
            CustomeExchange(identifier: "HKD", display: "港元"),
            CustomeExchange(identifier: "MOP", display: "澳门元"),
            CustomeExchange(identifier: "THB", display: "泰铢"),
            CustomeExchange(identifier: "SGD", display: "新加坡元"),
            CustomeExchange(identifier: "SGG", display: "SGD"),
        ]
    }
}
